package com.outlierradar.app

import android.app.Application
import android.content.*
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.util.LruCache
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Velocity
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.AndroidViewModel
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.IOException
import java.net.*
import java.security.MessageDigest
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.min
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import org.json.JSONObject

// =====================================================================
// 🎨 THEME TOKENS
// =====================================================================

private val BgColor = Color(0xFF0B0D12)
private val SurfaceColor = Color(0xFF151922)
private val SurfaceHigh = Color(0xFF1E2430)
private val Accent = Color(0xFFFF3D57)
private val AccentSoft = Color(0xFFFF7A59)
private val Electric = Color(0xFF7C5CFF)
private val Mint = Color(0xFF2FD39A)
private val Amber = Color(0xFFFFB547)
private val TextPrimary = Color(0xFFF2F4F8)
private val TextSecondary = Color(0xFF9AA3B2)
private val Divider = Color(0xFF2A3140)

private val RadarColors = darkColorScheme(
    primary = Accent,
    onPrimary = Color.White,
    secondary = Electric,
    onSecondary = Color.White,
    tertiary = Mint,
    background = BgColor,
    onBackground = TextPrimary,
    surface = SurfaceColor,
    onSurface = TextPrimary,
    surfaceVariant = SurfaceHigh,
    onSurfaceVariant = TextSecondary,
    outline = Divider,
    error = Accent
)

// =====================================================================
// 📦 MODELS
// =====================================================================

data class ChannelStats(val subscribers: Long, val hidden: Boolean)

data class Video(
    val id: String,
    val title: String,
    val channelId: String,
    val channelTitle: String,
    val thumbnailUrl: String,
    val publishedAt: String,
    val description: String,
    val tags: List<String>,
    val views: Long,
    val likes: Long,
    val comments: Long,
    val durationSec: Int,
    val subscribers: Long = 0L,
    val subsHidden: Boolean = true,
    val subsKnown: Boolean = false
) {
    val hasSubs: Boolean get() = subsKnown && !subsHidden

    val viewToSubRatio: Double?
        get() = if (hasSubs) views.toDouble() / max(subscribers, 1L).toDouble() else null

    val outlierScore: Int
        get() {
            val r = viewToSubRatio ?: return 0
            if (r <= 0.0) return 0
            return ((log10(r) + 1.0) * 25.0).toInt().coerceIn(0, 100)
        }

    val engagementRate: Double
        get() = if (views > 0) (likes + comments).toDouble() / views.toDouble() * 100.0 else 0.0

    val hoursSincePublish: Double
        get() {
            val t = parseIsoDate(publishedAt) ?: return 24.0
            return max((System.currentTimeMillis() - t) / 3_600_000.0, 1.0)
        }

    val viewsPerDay: Long get() = (views / hoursSincePublish * 24.0).toLong()

    val hashtags: List<String> by lazy { SmartData.hashtags(title, description, tags) }
    val hook: String by lazy { SmartData.hook(title) }
    val audio: String by lazy { SmartData.audio(description) }
    val url: String get() = "https://youtube.com/shorts/$id"
}

enum class ErrorKind { MISSING_KEY, INVALID_KEY, QUOTA, API_DISABLED, KEY_RESTRICTED, FORBIDDEN, TIMEOUT, NETWORK, UNKNOWN }

class ApiException(val kind: ErrorKind, val detail: String) : Exception(detail)

data class RadarError(val kind: ErrorKind, val detail: String = "")

enum class SortMode(val label: String) { OUTLIER("🔥 Outlier"), VIEWS("👁 Views"), VELOCITY("🚀 Velocity"), NEWEST("🆕 Newest") }

enum class TimeWindow(val label: String, val days: Int) { WEEK("7 days", 7), MONTH("30 days", 30), QUARTER("90 days", 90), ALL("All time", 0) }

enum class Tab(val emoji: String, val label: String) { HOME("📡", "Radar"), TRENDS("📈", "Trends"), SETTINGS("⚙️", "Settings") }

data class RadarState(
    val apiKey: String = "",
    val query: String = "",
    val lastQuery: String = "",
    val videos: List<Video> = emptyList(),
    val isLoading: Boolean = false,
    val isRefreshing: Boolean = false,
    val isLoadingMore: Boolean = false,
    val nextPageToken: String? = null,
    val endReached: Boolean = false,
    val error: RadarError? = null,
    val loadMoreError: RadarError? = null,
    val recentSearches: List<String> = emptyList(),
    val selectedVideo: Video? = null,
    val sortMode: SortMode = SortMode.OUTLIER,
    val timeWindow: TimeWindow = TimeWindow.MONTH,
    val tab: Tab = Tab.HOME,
    val keyTestMessage: String? = null,
    val isTestingKey: Boolean = false
)

// =====================================================================
// 🧠 SMART DATA
// =====================================================================

object SmartData {
    private val hashtagRegex = Regex("#[\\p{L}\\p{N}_]+")
    private val hookBreak = Regex("[|•—–!?.]")
    private val audioPatterns = listOf(
        Regex("(?:♪|🎵|🎶)\\s*([^\\n♪🎵🎶]{3,60})"),
        Regex("(?i)(?:song|music|audio|sound|track)\\s*[:\\-–]\\s*([^\\n]{3,60})")
    )
    val genericTags = setOf("#shorts", "#short", "#youtubeshorts", "#ytshorts")

    fun hashtags(title: String, description: String, tags: List<String>): List<String> {
        val found = LinkedHashSet<String>()
        hashtagRegex.findAll(title).forEach { found.add(it.value.lowercase(Locale.ROOT)) }
        hashtagRegex.findAll(description).forEach { found.add(it.value.lowercase(Locale.ROOT)) }
        tags.take(8).forEach { t ->
            val clean = t.replace(" ", "").lowercase(Locale.ROOT)
            if (clean.isNotBlank() && clean.length <= 30) found.add("#$clean")
        }
        return found.take(15)
    }

    fun hook(title: String): String {
        val clean = title.replace(hashtagRegex, "").replace(Regex("\\s+"), " ").trim()
        if (clean.isEmpty()) return title.take(50)
        val m = hookBreak.find(clean)
        var hook = if (m != null && m.range.first >= 8) {
            val c = clean[m.range.first]
            clean.substring(0, m.range.first + if (c == '!' || c == '?') 1 else 0)
        } else clean
        val words = hook.split(" ").filter { it.isNotBlank() }
        if (words.size > 8) hook = words.take(8).joinToString(" ") + "…"
        return hook.trim()
    }

    fun audio(description: String): String {
        for (p in audioPatterns) {
            val m = p.find(description)
            if (m != null) {
                val v = m.groupValues[1].trim().trim('-', ':', '|').trim()
                if (v.length >= 3) return v.take(50)
            }
        }
        return "Original audio"
    }

    fun hookPattern(title: String): String? {
        val t = title.trim().lowercase(Locale.ROOT)
        return when {
            t.startsWith("pov") -> "POV:"
            t.startsWith("how ") -> "How…"
            t.startsWith("why ") -> "Why…"
            t.startsWith("wait") -> "Wait for it…"
            t.startsWith("i tried") || t.startsWith("i tested") -> "I tried…"
            t.startsWith("nobody") || t.startsWith("no one") -> "Nobody talks about…"
            t.startsWith("stop ") || t.startsWith("don't") || t.startsWith("never ") -> "Stop / Don't…"
            t.startsWith("this ") -> "This…"
            t.contains("secret") -> "The secret…"
            t.firstOrNull()?.isDigit() == true -> "Numbered list (e.g. '3 ways…')"
            t.endsWith("?") -> "Question title"
            else -> null
        }
    }
}

// =====================================================================
// 🔢 FORMATTERS
// =====================================================================

fun formatCount(n: Long): String {
    fun f(v: Double, s: String): String {
        val str = if (v >= 100) String.format(Locale.US, "%.0f", v) else String.format(Locale.US, "%.1f", v)
        return str.removeSuffix(".0") + s
    }
    return when {
        n >= 1_000_000_000L -> f(n / 1_000_000_000.0, "B")
        n >= 1_000_000L -> f(n / 1_000_000.0, "M")
        n >= 1_000L -> f(n / 1_000.0, "K")
        else -> n.toString()
    }
}

fun formatRatio(r: Double): String = when {
    r >= 10.0 -> NumberFormat.getIntegerInstance(Locale.US).format(r.toLong()) + "x"
    r >= 1.0 -> String.format(Locale.US, "%.1f", r).removeSuffix(".0") + "x"
    else -> String.format(Locale.US, "%.2f", r) + "x"
}

fun formatDuration(sec: Int): String = "${sec / 60}:${(sec % 60).toString().padStart(2, '0')}"

fun parseIsoDate(s: String): Long? {
    if (s.isBlank()) return null
    return try {
        val fmt = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US)
        fmt.timeZone = TimeZone.getTimeZone("UTC")
        fmt.parse(s.take(19))?.time
    } catch (e: Exception) {
        null
    }
}

fun timeAgo(iso: String): String {
    val t = parseIsoDate(iso) ?: return ""
    val mins = (System.currentTimeMillis() - t) / 60_000L
    return when {
        mins < 60 -> "${max(mins, 1L)}m ago"
        mins < 60 * 24 -> "${mins / 60}h ago"
        mins < 60 * 24 * 30 -> "${mins / (60 * 24)}d ago"
        mins < 60 * 24 * 365 -> "${mins / (60 * 24 * 30)}mo ago"
        else -> "${mins / (60 * 24 * 365)}y ago"
    }
}

fun parseIsoDuration(d: String): Int {
    val m = Regex("P(?:(\\d+)D)?T?(?:(\\d+)H)?(?:(\\d+)M)?(?:(\\d+)S)?").find(d) ?: return 0
    val days = m.groupValues[1].toIntOrNull() ?: 0
    val h = m.groupValues[2].toIntOrNull() ?: 0
    val mi = m.groupValues[3].toIntOrNull() ?: 0
    val s = m.groupValues[4].toIntOrNull() ?: 0
    return days * 86400 + h * 3600 + mi * 60 + s
}

fun quotaResetText(): String {
    val pt = TimeZone.getTimeZone("America/Los_Angeles")
    val cal = Calendar.getInstance(pt)
    val now = cal.timeInMillis
    cal.add(Calendar.DAY_OF_YEAR, 1)
    cal.set(Calendar.HOUR_OF_DAY, 0)
    cal.set(Calendar.MINUTE, 0)
    cal.set(Calendar.SECOND, 0)
    cal.set(Calendar.MILLISECOND, 0)
    val diff = cal.timeInMillis - now
    val h = diff / 3_600_000L
    val m = (diff / 60_000L) % 60L
    val local = SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date(cal.timeInMillis))
    return "Resets in ${h}h ${m}m (at $local your time)."
}

// =====================================================================
// 🌐 YOUTUBE DATA API v3 REPOSITORY
// =====================================================================

data class PageResult(val videos: List<Video>, val nextPageToken: String?)

class YouTubeRepository(private val packageName: String, private val certSha1: String?) {

    private val base = "https://www.googleapis.com/youtube/v3"
    private val channelCache = ConcurrentHashMap<String, ChannelStats>()

    private fun enc(s: String): String = URLEncoder.encode(s, "UTF-8")

    private fun getJson(url: String): JSONObject {
        var conn: HttpURLConnection? = null
        try {
            val connection = (URL(url).openConnection() as HttpURLConnection).apply {
                connectTimeout = 10_000
                readTimeout = 10_000
                requestMethod = "GET"
                setRequestProperty("Accept", "application/json")
                setRequestProperty("X-Android-Package", packageName)
                if (certSha1 != null) setRequestProperty("X-Android-Cert", certSha1)
            }
            conn = connection
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val body = stream?.bufferedReader()?.use { it.readText() } ?: ""
            if (code !in 200..299) throw parseError(code, body)
            return JSONObject(body)
        } catch (e: ApiException) {
            throw e
        } catch (e: SocketTimeoutException) {
            throw ApiException(ErrorKind.TIMEOUT, "The server took longer than 10 seconds to respond.")
        } catch (e: UnknownHostException) {
            throw ApiException(ErrorKind.NETWORK, "No internet connection.")
        } catch (e: IOException) {
            throw ApiException(ErrorKind.NETWORK, e.message ?: "Network error")
        } catch (e: org.json.JSONException) {
            throw ApiException(ErrorKind.UNKNOWN, "Unexpected response from YouTube.")
        } finally {
            conn?.disconnect()
        }
    }

    private fun parseError(code: Int, body: String): ApiException {
        val err = try { JSONObject(body).optJSONObject("error") } catch (e: Exception) { null }
        val msg = err?.optString("message").orEmpty().replace(Regex("<[^>]*>"), "")
        val reason = err?.optJSONArray("errors")?.optJSONObject(0)?.optString("reason").orEmpty()
        val detailReason = err?.optJSONArray("details")?.optJSONObject(0)?.optString("reason").orEmpty()
        val kind = when {
            reason in setOf("quotaExceeded", "dailyLimitExceeded", "rateLimitExceeded", "userRateLimitExceeded") ||
                msg.contains("quota", ignoreCase = true) -> ErrorKind.QUOTA
            reason == "keyInvalid" || reason == "keyExpired" || detailReason == "API_KEY_INVALID" ||
                msg.contains("API key not valid", ignoreCase = true) ||
                msg.contains("API key expired", ignoreCase = true) -> ErrorKind.INVALID_KEY
            reason == "accessNotConfigured" || detailReason == "SERVICE_DISABLED" ||
                msg.contains("has not been used", ignoreCase = true) ||
                msg.contains("is disabled", ignoreCase = true) -> ErrorKind.API_DISABLED
            reason == "ipRefererBlocked" || detailReason == "API_KEY_ANDROID_APP_BLOCKED" ||
                msg.contains("blocked", ignoreCase = true) -> ErrorKind.KEY_RESTRICTED
            code == 403 -> ErrorKind.FORBIDDEN
            code == 400 && msg.contains("key", ignoreCase = true) -> ErrorKind.INVALID_KEY
            else -> ErrorKind.UNKNOWN
        }
        return ApiException(kind, if (msg.isNotBlank()) msg else "HTTP $code")
    }

    suspend fun testKey(key: String): Unit = withContext(Dispatchers.IO) {
        getJson("$base/videos?part=id&id=dQw4w9WgXcQ&key=${enc(key)}")
        Unit
    }

    suspend fun fetchPage(key: String, query: String, pageToken: String?, window: TimeWindow): PageResult =
        withContext(Dispatchers.IO) {
            val sb = StringBuilder("$base/search?part=snippet&type=video&videoDuration=short&order=viewCount&maxResults=25")
            sb.append("&q=").append(enc("$query #shorts"))
            if (window.days > 0) {
                val fmt = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US)
                fmt.timeZone = TimeZone.getTimeZone("UTC")
                val after = System.currentTimeMillis() - window.days * 86_400_000L
                sb.append("&publishedAfter=").append(enc(fmt.format(Date(after))))
            }
            if (!pageToken.isNullOrBlank()) sb.append("&pageToken=").append(enc(pageToken))
            sb.append("&key=").append(enc(key))

            val search = getJson(sb.toString())
            val next = search.optString("nextPageToken", "").ifBlank { null }
            val items = search.optJSONArray("items")
            val ids = ArrayList<String>()
            if (items != null) {
                for (i in 0 until items.length()) {
                    val vid = items.optJSONObject(i)?.optJSONObject("id")?.optString("videoId").orEmpty()
                    if (vid.isNotBlank() && vid !in ids) ids.add(vid)
                }
            }
            if (ids.isEmpty()) return@withContext PageResult(emptyList(), next)

            val vj = getJson("$base/videos?part=snippet,statistics,contentDetails&id=${enc(ids.joinToString(","))}&key=${enc(key)}")
            val vItems = vj.optJSONArray("items")
            val parsed = ArrayList<Video>()
            if (vItems != null) {
                for (i in 0 until vItems.length()) {
                    val o = vItems.optJSONObject(i) ?: continue
                    val sn = o.optJSONObject("snippet") ?: continue
                    val st = o.optJSONObject("statistics")
                    val cd = o.optJSONObject("contentDetails")
                    val thumbs = sn.optJSONObject("thumbnails")
                    val thumb = thumbs?.optJSONObject("high")?.optString("url")
                        ?: thumbs?.optJSONObject("medium")?.optString("url")
                        ?: thumbs?.optJSONObject("default")?.optString("url")
                        ?: "https://i.ytimg.com/vi/${o.optString("id")}/hqdefault.jpg"
                    val tagsArr = sn.optJSONArray("tags")
                    val tags = ArrayList<String>()
                    if (tagsArr != null) for (t in 0 until tagsArr.length()) tags.add(tagsArr.optString(t))
                    val duration = parseIsoDuration(cd?.optString("duration").orEmpty())
                    if (duration > 180) continue
                    parsed.add(
                        Video(
                            id = o.optString("id"),
                            title = sn.optString("title"),
                            channelId = sn.optString("channelId"),
                            channelTitle = sn.optString("channelTitle"),
                            thumbnailUrl = thumb,
                            publishedAt = sn.optString("publishedAt"),
                            description = sn.optString("description"),
                            tags = tags,
                            views = st?.optString("viewCount")?.toLongOrNull() ?: 0L,
                            likes = st?.optString("likeCount")?.toLongOrNull() ?: 0L,
                            comments = st?.optString("commentCount")?.toLongOrNull() ?: 0L,
                            durationSec = duration
                        )
                    )
                }
            }

            val missing = parsed.map { it.channelId }.distinct().filter { it.isNotBlank() && !channelCache.containsKey(it) }
            for (chunk in missing.chunked(50)) {
                try {
                    val cj = getJson("$base/channels?part=statistics&id=${enc(chunk.joinToString(","))}&key=${enc(key)}")
                    val cItems = cj.optJSONArray("items")
                    if (cItems != null) {
                        for (i in 0 until cItems.length()) {
                            val c = cItems.optJSONObject(i) ?: continue
                            val cs = c.optJSONObject("statistics") ?: continue
                            channelCache[c.optString("id")] = ChannelStats(
                                subscribers = cs.optString("subscriberCount").toLongOrNull() ?: 0L,
                                hidden = cs.optBoolean("hiddenSubscriberCount", false)
                            )
                        }
                    }
                } catch (e: ApiException) {
                    if (e.kind == ErrorKind.QUOTA || e.kind == ErrorKind.INVALID_KEY) throw e
                }
            }

            val withSubs = parsed.map { v ->
                val cs = channelCache[v.channelId]
                if (cs == null) v else v.copy(subscribers = cs.subscribers, subsHidden = cs.hidden, subsKnown = true)
            }
            PageResult(withSubs, next)
        }
}

// =====================================================================
// 🖼️ NATIVE IMAGE LOADER
// =====================================================================

object ImageLoader {
    private const val DISK_LIMIT_BYTES = 60L * 1024L * 1024L
    private const val TARGET_WIDTH = 360

    private val memory: LruCache<String, Bitmap> by lazy {
        val maxKb = (Runtime.getRuntime().maxMemory() / 1024L).toInt()
        object : LruCache<String, Bitmap>(maxKb / 8) {
            override fun sizeOf(key: String, value: Bitmap): Int = max(value.byteCount / 1024, 1)
        }
    }
    private val network = Semaphore(4)
    private val failed = ConcurrentHashMap<String, Long>()
    @Volatile private var writes = 0

    fun fromMemory(url: String): Bitmap? = memory.get(url)

    private fun diskDir(ctx: Context): File = File(ctx.cacheDir, "thumbs").apply { if (!exists()) mkdirs() }

    private fun keyFor(url: String): String {
        val md = MessageDigest.getInstance("MD5")
        return md.digest(url.toByteArray()).joinToString("") { String.format(Locale.US, "%02x", it.toInt() and 0xff) }
    }

    suspend fun load(ctx: Context, url: String): Bitmap? {
        memory.get(url)?.let { return it }
        val lastFail = failed[url]
        if (lastFail != null && System.currentTimeMillis() - lastFail < 30_000L) return null
        return withContext(Dispatchers.IO) {
            memory.get(url)?.let { return@withContext it }
            val file = File(diskDir(ctx), keyFor(url))
            var bytes: ByteArray? = null
            if (file.exists() && file.length() > 0) {
                bytes = try { file.readBytes() } catch (e: Exception) { null }
                if (bytes != null) file.setLastModified(System.currentTimeMillis())
            }
            if (bytes == null) {
                bytes = network.withPermit { download(url) }
                if (bytes != null) {
                    try {
                        file.writeBytes(bytes)
                        writes++
                        if (writes % 40 == 0) trimDisk(ctx)
                    } catch (e: Exception) { }
                }
            }
            val bmp = bytes?.let { decode(it) }
            if (bmp != null) memory.put(url, bmp) else failed[url] = System.currentTimeMillis()
            bmp
        }
    }

    private fun download(url: String): ByteArray? {
        var conn: HttpURLConnection? = null
        return try {
            val connection = (URL(url).openConnection() as HttpURLConnection).apply {
                connectTimeout = 10_000
                readTimeout = 10_000
            }
            conn = connection
            if (connection.responseCode !in 200..299) return null
            connection.inputStream.use { input ->
                val out = ByteArrayOutputStream()
                val buf = ByteArray(16 * 1024)
                while (true) {
                    val n = input.read(buf)
                    if (n < 0) break
                    out.write(buf, 0, n)
                }
                out.toByteArray()
            }
        } catch (e: Exception) {
            null
        } finally {
            conn?.disconnect()
        }
    }

    private fun decode(bytes: ByteArray): Bitmap? = try {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        var sample = 1
        while (bounds.outWidth / (sample * 2) >= TARGET_WIDTH) sample *= 2
        val opts = BitmapFactory.Options().apply {
            inSampleSize = sample
            inPreferredConfig = Bitmap.Config.RGB_565
        }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts)
    } catch (e: OutOfMemoryError) {
        memory.evictAll()
        null
    } catch (e: Exception) {
        null
    }

    private fun trimDisk(ctx: Context) {
        val files = diskDir(ctx).listFiles() ?: return
        var total = files.sumOf { it.length() }
        if (total <= DISK_LIMIT_BYTES) return
        for (f in files.sortedBy { it.lastModified() }) {
            if (total <= DISK_LIMIT_BYTES * 3 / 4) break
            total -= f.length()
            f.delete()
        }
    }

    fun clear(ctx: Context) {
        memory.evictAll()
        failed.clear()
        diskDir(ctx).listFiles()?.forEach { it.delete() }
    }

    fun onLowMemory() = memory.evictAll()
    fun trimHalf() = memory.trimToSize(memory.maxSize() / 2)
}

// =====================================================================
// 🧭 VIEWMODEL
// =====================================================================

class RadarViewModel(app: Application) : AndroidViewModel(app) {

    private val prefs: SharedPreferences = app.getSharedPreferences("outlier_radar", Context.MODE_PRIVATE)
    private val repo = YouTubeRepository(app.packageName, signingSha1(app))
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var searchJob: Job? = null
    private var moreJob: Job? = null

    private val _state = MutableStateFlow(
        RadarState(
            apiKey = prefs.getString("api_key", "") ?: "",
            recentSearches = (prefs.getString("recent", "") ?: "").split("\u0001").filter { it.isNotBlank() }.take(5)
        )
    )
    val state: StateFlow<RadarState> = _state.asStateFlow()

    init {
        if (_state.value.apiKey.isBlank()) _state.update { it.copy(tab = Tab.SETTINGS) }
    }

    fun setTab(t: Tab) = _state.update { it.copy(tab = t) }
    fun updateQuery(q: String) = _state.update { it.copy(query = q) }
    fun setSort(m: SortMode) = _state.update { it.copy(sortMode = m) }
    fun openInspector(v: Video) = _state.update { it.copy(selectedVideo = v) }
    fun closeInspector() = _state.update { it.copy(selectedVideo = null) }
    fun dismissError() = _state.update { it.copy(error = null) }

    fun setWindow(w: TimeWindow) {
        _state.update { it.copy(timeWindow = w) }
        val q = _state.value.lastQuery
        if (q.isNotBlank()) search(q)
    }

    fun saveApiKey(key: String) {
        val k = key.trim()
        prefs.edit().putString("api_key", k).apply()
        _state.update { it.copy(apiKey = k, keyTestMessage = null, error = if (it.error?.kind == ErrorKind.MISSING_KEY) null else it.error) }
    }

    fun clearRecent() {
        prefs.edit().remove("recent").apply()
        _state.update { it.copy(recentSearches = emptyList()) }
    }

    private fun pushRecent(q: String) {
        val list = (listOf(q) + _state.value.recentSearches.filter { !it.equals(q, ignoreCase = true) }).take(5)
        prefs.edit().putString("recent", list.joinToString("\u0001")).apply()
        _state.update { it.copy(recentSearches = list) }
    }

    fun testKey(key: String) {
        val k = key.trim()
        if (k.isBlank()) {
            _state.update { it.copy(keyTestMessage = "⚠️ Enter a key first.") }
            return
        }
        _state.update { it.copy(isTestingKey = true, keyTestMessage = null) }
        scope.launch {
            val msg = try {
                repo.testKey(k)
                "✅ Key works. YouTube Data API v3 is reachable."
            } catch (e: ApiException) {
                val ui = errorUi(RadarError(e.kind, e.detail))
                "${ui.emoji} ${ui.title}: ${ui.message}"
            } catch (e: Exception) {
                "❌ ${e.message ?: "Unknown error"}"
            }
            _state.update { it.copy(isTestingKey = false, keyTestMessage = msg) }
        }
    }

    fun search(raw: String = _state.value.query, refresh: Boolean = false) {
        val q = raw.trim()
        if (q.isEmpty()) return
        val key = _state.value.apiKey
        if (key.isBlank()) {
            _state.update { it.copy(error = RadarError(ErrorKind.MISSING_KEY), query = q) }
            return
        }
        pushRecent(q)
        searchJob?.cancel()
        moreJob?.cancel()
        _state.update {
            it.copy(
                query = q, lastQuery = q,
                isLoading = !refresh, isRefreshing = refresh, isLoadingMore = false,
                error = null, loadMoreError = null, endReached = false,
                videos = if (refresh) it.videos else emptyList(), nextPageToken = null
            )
        }
        searchJob = scope.launch {
            try {
                var page = repo.fetchPage(key, q, null, _state.value.timeWindow)
                val collected = LinkedHashMap<String, Video>()
                page.videos.forEach { collected[it.id] = it }
                var hops = 0
                while (collected.size < 8 && page.nextPageToken != null && hops < 2) {
                    page = repo.fetchPage(key, q, page.nextPageToken, _state.value.timeWindow)
                    page.videos.forEach { if (!collected.containsKey(it.id)) collected[it.id] = it }
                    hops++
                }
                _state.update {
                    it.copy(
                        videos = collected.values.toList(), nextPageToken = page.nextPageToken,
                        endReached = page.nextPageToken == null, isLoading = false, isRefreshing = false
                    )
                }
            } catch (e: ApiException) {
                _state.update { it.copy(isLoading = false, isRefreshing = false, error = RadarError(e.kind, e.detail)) }
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: Exception) {
                _state.update { it.copy(isLoading = false, isRefreshing = false, error = RadarError(ErrorKind.UNKNOWN, e.message ?: "")) }
            }
        }
    }

    fun refresh() {
        val q = _state.value.lastQuery
        if (q.isNotBlank()) search(q, refresh = true)
    }

    fun loadMore(force: Boolean = false) {
        val s = _state.value
        if (s.isLoading || s.isRefreshing || s.isLoadingMore || s.endReached) return
        if (s.loadMoreError != null && !force) return
        val token = s.nextPageToken ?: return
        _state.update { it.copy(isLoadingMore = true, loadMoreError = null) }
        moreJob = scope.launch {
            try {
                var next: String? = token
                var added = 0
                var hops = 0
                val existing = LinkedHashMap<String, Video>()
                _state.value.videos.forEach { existing[it.id] = it }
                while (next != null && added == 0 && hops < 3) {
                    val page = repo.fetchPage(s.apiKey, s.lastQuery, next, s.timeWindow)
                    page.videos.forEach { v -> if (!existing.containsKey(v.id)) { existing[v.id] = v; added++ } }
                    next = page.nextPageToken
                    hops++
                }
                _state.update {
                    it.copy(videos = existing.values.toList(), nextPageToken = next, endReached = next == null, isLoadingMore = false)
                }
            } catch (e: ApiException) {
                _state.update { it.copy(isLoadingMore = false, loadMoreError = RadarError(e.kind, e.detail)) }
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: Exception) {
                _state.update { it.copy(isLoadingMore = false, loadMoreError = RadarError(ErrorKind.UNKNOWN, e.message ?: "")) }
            }
        }
    }

    override fun onCleared() {
        scope.cancel()
        super.onCleared()
    }

    companion object {
        @Suppress("DEPRECATION")
        fun signingSha1(ctx: Context): String? {
            return try {
                val info = ctx.packageManager.getPackageInfo(ctx.packageName, PackageManager.GET_SIGNATURES)
                val sigs = info.signatures
                if (sigs == null || sigs.isEmpty()) return null
                val md = MessageDigest.getInstance("SHA1")
                md.digest(sigs[0].toByteArray()).joinToString("") { String.format(Locale.US, "%02X", it.toInt() and 0xff) }
            } catch (e: Exception) {
                null
            }
        }
    }
}

// =====================================================================
// ❗ FRIENDLY ERROR MAPPING
// =====================================================================

data class ErrorUi(val emoji: String, val title: String, val message: String, val showSettings: Boolean)

fun errorUi(e: RadarError): ErrorUi = when (e.kind) {
    ErrorKind.MISSING_KEY -> ErrorUi("🔑", "API key needed", "Add your YouTube Data API v3 key in Settings to start scanning.", true)
    ErrorKind.INVALID_KEY -> ErrorUi("🚫", "Invalid API key", "YouTube rejected this key. Double-check it in Google Cloud Console → Credentials.", true)
    ErrorKind.QUOTA -> ErrorUi("⏳", "Daily quota reached", "You've used today's free YouTube API quota. ${quotaResetText()} Searches are the most expensive calls, so cached results still work.", false)
    ErrorKind.API_DISABLED -> ErrorUi("🧩", "API not enabled", "Enable \"YouTube Data API v3\" for this key's Google Cloud project, then retry.", true)
    ErrorKind.KEY_RESTRICTED -> ErrorUi("🛡️", "Key is restricted", "This key's restrictions block this app. Allow package com.outlierradar.app (with its SHA-1) or remove restrictions.", true)
    ErrorKind.FORBIDDEN -> ErrorUi("⛔", "Access denied (403)", e.detail.ifBlank { "YouTube refused the request." }, true)
    ErrorKind.TIMEOUT -> ErrorUi("🐢", "Request timed out", "YouTube didn't answer within 10 seconds. Check your connection and retry.", false)
    ErrorKind.NETWORK -> ErrorUi("📶", "You're offline", "Couldn't reach YouTube. Check Wi-Fi or mobile data.", false)
    ErrorKind.UNKNOWN -> ErrorUi("⚠️", "Something went wrong", e.detail.ifBlank { "Unexpected error. Please retry." }, false)
}

// =====================================================================
// 📊 TRENDS ENGINE
// =====================================================================

data class ActionStep(val emoji: String, val title: String, val detail: String)

data class TrendReport(
    val count: Int,
    val avgRatio: Double,
    val topRatio: Double,
    val smallCreatorShare: Int,
    val hashtags: List<Pair<String, Int>>,
    val audio: List<Pair<String, Int>>,
    val hooks: List<Video>,
    val topOutliers: List<Video>,
    val plan: List<ActionStep>
)

fun buildTrends(videos: List<Video>): TrendReport? {
    if (videos.isEmpty()) return null
    val withRatio = videos.filter { it.viewToSubRatio != null }
    val ranked = withRatio.sortedByDescending { it.viewToSubRatio ?: 0.0 }
    val top = if (ranked.isNotEmpty()) ranked.take(max(5, ranked.size / 4)) else videos.sortedByDescending { it.views }.take(5)

    val tagCounts = HashMap<String, Int>()
    videos.forEach { v -> v.hashtags.filter { it !in SmartData.genericTags }.forEach { tagCounts[it] = (tagCounts[it] ?: 0) + 1 } }
    val hashtags = tagCounts.entries.sortedByDescending { it.value }.take(8).map { it.key to it.value }

    val audioCounts = HashMap<String, Int>()
    videos.forEach { v -> audioCounts[v.audio] = (audioCounts[v.audio] ?: 0) + 1 }
    val audio = audioCounts.entries.sortedByDescending { it.value }.take(5).map { it.key to it.value }

    val small = withRatio.count { it.subscribers < 50_000L }
    val smallShare = if (withRatio.isNotEmpty()) small * 100 / withRatio.size else 0
    val avg = if (withRatio.isNotEmpty()) withRatio.map { it.viewToSubRatio ?: 0.0 }.average() else 0.0

    val patternCounts = HashMap<String, Int>()
    top.forEach { v -> SmartData.hookPattern(v.title)?.let { p -> patternCounts[p] = (patternCounts[p] ?: 0) + 1 } }
    val bestPattern = patternCounts.entries.maxByOrNull { it.value }
    val best = top.first()
    val step1 = if (bestPattern != null && bestPattern.value >= 2) {
        ActionStep("🪝", "Open with a \"${bestPattern.key}\" hook",
            "${bestPattern.value} of the top ${top.size} outliers use this opener. Model it on: \"${best.hook}\" (${best.viewToSubRatio?.let { formatRatio(it) } ?: formatCount(best.views)} for ${best.channelTitle}). Say it in the first 1.5 seconds and put it on-screen as text.")
    } else {
        ActionStep("🪝", "Use the hook \"${best.hook}\"",
            "This opener drove ${best.viewToSubRatio?.let { formatRatio(it) + " views-to-subs" } ?: formatCount(best.views) + " views"} for ${best.channelTitle}. Rephrase it for your angle and land it in the first 1.5 seconds.")
    }

    val namedAudio = audio.firstOrNull { it.first != "Original audio" }
    val originalCount = audioCounts["Original audio"] ?: 0
    val tagLine = hashtags.take(3).joinToString(" ") { it.first }
    val step2 = if (namedAudio != null && namedAudio.second >= 2) {
        ActionStep("🎵", "Use trending audio \"${namedAudio.first}\"",
            "It appears in ${namedAudio.second} results in this niche. Pair it with ${if (tagLine.isNotBlank()) tagLine else "#shorts"} to ride the same recommendation cluster.")
    } else {
        val pct = originalCount * 100 / videos.size
        ActionStep("🎙️", "Lead with original voice-over",
            "$pct% of these Shorts run on original audio, so a clear voice-over beats a trending sound here. Stack ${if (tagLine.isNotBlank()) tagLine else "#shorts"} as your hashtags.")
    }

    val topSubs = top.filter { it.hasSubs }.map { it.subscribers }.sorted()
    val medianSubs = if (topSubs.isNotEmpty()) topSubs[topSubs.size / 2] else 0L
    val step3 = when {
        topSubs.isEmpty() -> ActionStep("👥", "Benchmark against small channels",
            "Subscriber counts are hidden for these results. Compare your views against channels of a similar size.")
        medianSubs < 10_000L -> ActionStep("🌱", "Micro creators win here (under 10K subs)",
            "Top outliers have a median of ${formatCount(medianSubs)} subs. The algorithm is distributing new channels in this niche — post daily for 14 days.")
        medianSubs < 50_000L -> ActionStep("🎯", "Target a small-creator lane (under 50K subs)",
            "Median top-outlier channel has ${formatCount(medianSubs)} subs and $smallShare% of results come from channels under 50K. Study them, not the giants.")
        medianSubs < 250_000L -> ActionStep("📈", "Mid-size channels dominate (50K–250K)",
            "Median top outlier has ${formatCount(medianSubs)} subs. Expect higher production bars: tighter edits, captions, and a payoff under 30s.")
        else -> ActionStep("🏔️", "Saturated by big channels (${formatCount(medianSubs)}+ subs)",
            "Large creators own this keyword. Niche down with a more specific query to find the small-creator gaps.")
    }

    return TrendReport(
        count = videos.size,
        avgRatio = avg,
        topRatio = ranked.firstOrNull()?.viewToSubRatio ?: 0.0,
        smallCreatorShare = smallShare,
        hashtags = hashtags,
        audio = audio,
        hooks = top.take(5),
        topOutliers = ranked.take(5),
        plan = listOf(step1, step2, step3)
    )
}

// =====================================================================
// 📤 SHARE / INTENT HELPERS
// =====================================================================

fun buildShareText(v: Video): String = buildString {
    appendLine("📡 Outlier Radar Report")
    appendLine()
    appendLine("🎬 ${v.title}")
    appendLine("👤 Channel: ${v.channelTitle}")
    appendLine("👁 Views: ${formatCount(v.views)}")
    appendLine("👥 Subs: ${if (v.hasSubs) formatCount(v.subscribers) else "Hidden"}")
    v.viewToSubRatio?.let { appendLine("🔥 View-to-Sub: ${formatRatio(it)}") }
    appendLine("⚡ Outlier Score: ${v.outlierScore}/100")
    appendLine("💬 Engagement: ${String.format(Locale.US, "%.2f", v.engagementRate)}%")
    appendLine("🪝 Hook: ${v.hook}")
    appendLine("🎵 Audio: ${v.audio}")
    if (v.hashtags.isNotEmpty()) appendLine("#️⃣ ${v.hashtags.take(10).joinToString(" ")}")
    appendLine()
    append("🔗 ${v.url}")
}

fun shareText(ctx: Context, text: String, subject: String) {
    val send = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_SUBJECT, subject)
        putExtra(Intent.EXTRA_TEXT, text)
    }
    val chooser = Intent.createChooser(send, "Share via").apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
    try {
        ctx.startActivity(chooser)
    } catch (e: ActivityNotFoundException) {
        Toast.makeText(ctx, "No app available to share", Toast.LENGTH_SHORT).show()
    }
}

fun openUrl(ctx: Context, url: String) {
    try {
        ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: ActivityNotFoundException) {
        Toast.makeText(ctx, "No app can open this link", Toast.LENGTH_SHORT).show()
    }
}

fun copyText(ctx: Context, text: String) {
    val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
    cm?.setPrimaryClip(ClipData.newPlainText("Outlier Radar", text))
    Toast.makeText(ctx, "Copied", Toast.LENGTH_SHORT).show()
}

// =====================================================================
// 🚀 ACTIVITY
// =====================================================================

class MainActivity : ComponentActivity() {
    private val vm: RadarViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = RadarColors) {
                Surface(modifier = Modifier.fillMaxSize(), color = BgColor) {
                    RadarApp(vm)
                }
            }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onLowMemory() {
        super.onLowMemory()
        ImageLoader.onLowMemory()
    }

    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        if (level >= 15) ImageLoader.trimHalf()
    }
}

// =====================================================================
// 🧱 ROOT UI
// =====================================================================

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RadarApp(vm: RadarViewModel) {
    val state by vm.state.collectAsState()

    Scaffold(
        containerColor = BgColor,
        bottomBar = {
            NavigationBar(containerColor = SurfaceColor) {
                Tab.values().forEach { t ->
                    NavigationBarItem(
                        selected = state.tab == t,
                        onClick = { vm.setTab(t) },
                        icon = { Text(t.emoji, fontSize = 20.sp) },
                        label = { Text(t.label) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedTextColor = Accent,
                            unselectedTextColor = TextSecondary,
                            indicatorColor = Accent.copy(alpha = 0.18f)
                        )
                    )
                }
            }
        }
    ) { padding ->
        Box(modifier = Modifier.fillMaxSize().padding(padding)) {
            when (state.tab) {
                Tab.HOME -> HomeScreen(state, vm)
                Tab.TRENDS -> TrendsScreen(state, vm)
                Tab.SETTINGS -> SettingsScreen(state, vm)
            }
        }
    }

    val selected = state.selectedVideo
    if (selected != null) {
        VideoInspectorSheet(video = selected, onDismiss = { vm.closeInspector() })
    }
}

// =====================================================================
// 🏠 HOME
// =====================================================================

@Composable
fun HomeScreen(state: RadarState, vm: RadarViewModel) {
    val focus = LocalFocusManager.current
    val listState = rememberLazyListState()
    val animatedIds = remember { HashSet<String>() }

    val sorted = remember(state.videos, state.sortMode) {
        when (state.sortMode) {
            SortMode.OUTLIER -> state.videos.sortedWith(compareByDescending<Video> { it.viewToSubRatio ?: -1.0 }.thenByDescending { it.views })
            SortMode.VIEWS -> state.videos.sortedByDescending { it.views }
            SortMode.VELOCITY -> state.videos.sortedByDescending { it.viewsPerDay }
            SortMode.NEWEST -> state.videos.sortedByDescending { parseIsoDate(it.publishedAt) ?: 0L }
        }
    }

    val shouldLoadMore by remember {
        derivedStateOf {
            val info = listState.layoutInfo
            val last = info.visibleItemsInfo.lastOrNull()?.index ?: 0
            info.totalItemsCount > 0 && last >= info.totalItemsCount - 4
        }
    }
    LaunchedEffect(shouldLoadMore, state.videos.size) {
        if (shouldLoadMore) vm.loadMore()
    }
    LaunchedEffect(state.lastQuery, state.timeWindow) {
        animatedIds.clear()
        if (listState.firstVisibleItemIndex > 0) listState.scrollToItem(0)
    }

    Column(modifier = Modifier.fillMaxSize()) {
        Row(modifier = Modifier.fillMaxWidth().padding(start = 16.dp, end = 16.dp, top = 14.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("📡", fontSize = 26.sp)
            Spacer(Modifier.width(8.dp))
            Column {
                Text("Outlier Radar", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, color = TextPrimary)
                Text("Find Shorts that outperform their channel", fontSize = 12.sp, color = TextSecondary)
            }
        }

        OutlinedTextField(
            value = state.query,
            onValueChange = { vm.updateQuery(it) },
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
            placeholder = { Text("Search a niche, e.g. gym motivation", color = TextSecondary) },
            leadingIcon = { Text("🔍", fontSize = 18.sp) },
            trailingIcon = {
                if (state.query.isNotEmpty()) {
                    Text("✖️", fontSize = 14.sp, modifier = Modifier.clip(CircleShape).clickable { vm.updateQuery("") }.padding(10.dp))
                }
            },
            singleLine = true,
            shape = RoundedCornerShape(16.dp),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = {
                focus.clearFocus()
                vm.search()
            }),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = Accent,
                unfocusedBorderColor = Divider,
                focusedContainerColor = SurfaceColor,
                unfocusedContainerColor = SurfaceColor,
                cursorColor = Accent,
                focusedTextColor = TextPrimary,
                unfocusedTextColor = TextPrimary
            )
        )

        AnimatedVisibility(visible = state.query.isEmpty() && state.recentSearches.isNotEmpty(), enter = fadeIn(), exit = fadeOut()) {
            Column {
                Row(modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("🕘 Recent", fontSize = 12.sp, color = TextSecondary, modifier = Modifier.weight(1f))
                    Text("Clear", fontSize = 12.sp, color = Accent, modifier = Modifier.clickable { vm.clearRecent() }.padding(4.dp))
                }
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(state.recentSearches, key = { it }) { term ->
                        Pill(text = term, emoji = "↻", selected = false, onClick = {
                            focus.clearFocus()
                            vm.updateQuery(term)
                            vm.search(term)
                        })
                    }
                }
            }
        }

        LazyRow(contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(TimeWindow.values().toList(), key = { "w" + it.name }) { w ->
                Pill(text = w.label, emoji = "📅", selected = state.timeWindow == w, onClick = { vm.setWindow(w) })
            }
        }
        LazyRow(contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(SortMode.values().toList(), key = { "s" + it.name }) { m ->
                Pill(text = m.label, emoji = null, selected = state.sortMode == m, onClick = { vm.setSort(m) })
            }
        }

        Box(modifier = Modifier.fillMaxSize()) {
            when {
                state.isLoading -> SkeletonList()
                state.error != null && state.videos.isEmpty() -> ErrorPanel(
                    error = state.error,
                    onRetry = { vm.search(state.lastQuery.ifBlank { state.query }) },
                    onSettings = { vm.setTab(Tab.SETTINGS) }
                )
                state.videos.isEmpty() && state.lastQuery.isNotBlank() -> EmptyPanel("🕳️", "No Shorts found", "Try a broader keyword or a longer time window.")
                state.videos.isEmpty() -> EmptyPanel("🛰️", "Ready to scan", "Search any niche to surface Shorts that massively outperform their channel's subscriber count.")
            }

            FadeSlideVisibility(visible = !state.isLoading && state.videos.isNotEmpty()) {
                PullToRefreshLayout(refreshing = state.isRefreshing, onRefresh = { vm.refresh() }) {
                    LazyColumn(
                        state = listState,
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 24.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        item(key = "summary") { SummaryStrip(state.videos) }
                        if (state.error != null) {
                            item(key = "inline_error") {
                                InlineError(state.error, onRetry = { vm.refresh() }, onDismiss = { vm.dismissError() })
                            }
                        }
                        items(sorted, key = { it.id }) { video ->
                            val visState = remember(video.id) {
                                MutableTransitionState(animatedIds.contains(video.id)).apply { targetState = true }
                            }
                            LaunchedEffect(video.id) { animatedIds.add(video.id) }
                            AnimatedEntry(visState) {
                                VideoCard(video = video, onClick = { vm.openInspector(video) })
                            }
                        }
                        item(key = "footer") {
                            LoadMoreFooter(state, onRetry = { vm.loadMore(force = true) })
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun FadeSlideVisibility(visible: Boolean, content: @Composable () -> Unit) {
    AnimatedVisibility(
        visible = visible,
        enter = fadeIn(tween(400)) + slideInVertically(tween(400)) { it / 10 },
        exit = fadeOut(tween(150))
    ) { content() }
}

@Composable
fun AnimatedEntry(state: MutableTransitionState<Boolean>, content: @Composable () -> Unit) {
    AnimatedVisibility(
        visibleState = state,
        enter = fadeIn(tween(350)) + slideInVertically(tween(350)) { it / 5 }
    ) { content() }
}

@Composable
fun Pill(text: String, emoji: String?, selected: Boolean, onClick: () -> Unit) {
    val bg = if (selected) Accent.copy(alpha = 0.2f) else SurfaceColor
    val border = if (selected) Accent else Divider
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(bg)
            .border(1.dp, border, RoundedCornerShape(50))
            .clickable { onClick() }
            .padding(horizontal = 12.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (emoji != null) {
            Text(emoji, fontSize = 12.sp, color = if (selected) Accent else TextSecondary)
            Spacer(Modifier.width(6.dp))
        }
        Text(text, fontSize = 13.sp, color = if (selected) TextPrimary else TextSecondary, maxLines = 1)
    }
}

@Composable
fun SummaryStrip(videos: List<Video>) {
    val ratios = videos.mapNotNull { it.viewToSubRatio }
    val avg = if (ratios.isNotEmpty()) ratios.average() else 0.0
    val top = ratios.maxOrNull() ?: 0.0
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        StatTile("🎬", "${videos.size}", "Shorts", Modifier.weight(1f))
        StatTile("📊", formatRatio(avg), "Avg ratio", Modifier.weight(1f))
        StatTile("🏆", formatRatio(top), "Top outlier", Modifier.weight(1f))
    }
}

@Composable
fun StatTile(emoji: String, value: String, label: String, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier.clip(RoundedCornerShape(14.dp)).background(SurfaceColor).padding(vertical = 10.dp, horizontal = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(emoji, fontSize = 16.sp)
        Text(value, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = TextPrimary, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(label, fontSize = 11.sp, color = TextSecondary, maxLines = 1)
    }
}

fun ratioColor(r: Double?): Color = when {
    r == null -> TextSecondary
    r >= 100.0 -> Accent
    r >= 10.0 -> AccentSoft
    r >= 1.0 -> Mint
    else -> TextSecondary
}

@Composable
fun VideoCard(video: Video, onClick: () -> Unit) {
    val ratio = video.viewToSubRatio
    Card(
        modifier = Modifier.fillMaxWidth().clickable { onClick() },
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceColor)
    ) {
        Row(modifier = Modifier.padding(10.dp)) {
            Box(modifier = Modifier.width(96.dp).height(150.dp).clip(RoundedCornerShape(12.dp))) {
                NetworkImage(url = video.thumbnailUrl, modifier = Modifier.fillMaxSize())
                Text(
                    formatDuration(video.durationSec),
                    fontSize = 10.sp, color = Color.White, fontWeight = FontWeight.Bold,
                    modifier = Modifier.align(Alignment.BottomEnd).padding(6.dp)
                        .clip(RoundedCornerShape(6.dp)).background(Color.Black.copy(alpha = 0.7f))
                        .padding(horizontal = 5.dp, vertical = 2.dp)
                )
                if (video.outlierScore >= 75) {
                    Text(
                        "🔥", fontSize = 14.sp,
                        modifier = Modifier.align(Alignment.TopStart).padding(6.dp)
                            .clip(CircleShape).background(Color.Black.copy(alpha = 0.6f)).padding(4.dp)
                    )
                }
            }
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(video.title, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = TextPrimary, maxLines = 2, overflow = TextOverflow.Ellipsis, lineHeight = 18.sp)
                Spacer(Modifier.height(4.dp))
                Text("👤 ${video.channelTitle} • ${timeAgo(video.publishedAt)}", fontSize = 12.sp, color = TextSecondary, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Spacer(Modifier.height(8.dp))
                Text(
                    "👁 ${formatCount(video.views)} views | 👥 ${if (video.hasSubs) formatCount(video.subscribers) + " Subs" else "Subs hidden"}",
                    fontSize = 12.sp, color = TextPrimary, maxLines = 1, overflow = TextOverflow.Ellipsis
                )
                Spacer(Modifier.height(8.dp))
                Box(
                    modifier = Modifier.clip(RoundedCornerShape(10.dp))
                        .background(Brush.horizontalGradient(listOf(ratioColor(ratio).copy(alpha = 0.28f), ratioColor(ratio).copy(alpha = 0.08f))))
                        .border(1.dp, ratioColor(ratio).copy(alpha = 0.6f), RoundedCornerShape(10.dp))
                        .padding(horizontal = 10.dp, vertical = 5.dp)
                ) {
                    Text(
                        if (ratio != null) "🔥 ${formatRatio(ratio)} Outlier" else "🔒 Ratio unavailable",
                        fontSize = 14.sp, fontWeight = FontWeight.ExtraBold, color = ratioColor(ratio), maxLines = 1
                    )
                }
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    MiniBadge("⚡ ${video.outlierScore}", Electric)
                    Spacer(Modifier.width(6.dp))
                    MiniBadge("🚀 ${formatCount(video.viewsPerDay)}/day", Amber)
                }
            }
        }
    }
}

@Composable
fun MiniBadge(text: String, color: Color) {
    Text(
        text, fontSize = 11.sp, color = color, fontWeight = FontWeight.SemiBold, maxLines = 1,
        modifier = Modifier.clip(RoundedCornerShape(8.dp)).background(color.copy(alpha = 0.14f)).padding(horizontal = 7.dp, vertical = 3.dp)
    )
}

@Composable
fun LoadMoreFooter(state: RadarState, onRetry: () -> Unit) {
    Box(modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp), contentAlignment = Alignment.Center) {
        when {
            state.isLoadingMore -> Row(verticalAlignment = Alignment.CenterVertically) {
                CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp, color = Accent)
                Spacer(modifier = Modifier.width(10.dp))
                Text("Loading 25 more Shorts…", fontSize = 12.sp, color = TextSecondary)
            }
            state.loadMoreError != null -> {
                val ui = errorUi(state.loadMoreError)
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("${ui.emoji} ${ui.title}", fontSize = 13.sp, color = TextPrimary, fontWeight = FontWeight.SemiBold)
                    if (state.loadMoreError.kind != ErrorKind.QUOTA) {
                        TextButton(onClick = onRetry) { Text("↻ Retry", color = Accent) }
                    } else {
                        Text(quotaResetText(), fontSize = 11.sp, color = TextSecondary, textAlign = TextAlign.Center)
                    }
                }
            }
            state.endReached -> Text("🏁 You've reached the end of the radar", fontSize = 12.sp, color = TextSecondary)
            else -> Spacer(Modifier.height(24.dp))
        }
    }
}

// =====================================================================
// ✨ SHIMMER SKELETON
// =====================================================================

@Composable
fun rememberShimmerBrush(): Brush {
    val transition = rememberInfiniteTransition()
    val x by transition.animateFloat(
        initialValue = -600f,
        targetValue = 1600f,
        animationSpec = infiniteRepeatable(animation = tween(durationMillis = 1300, easing = LinearEasing), repeatMode = RepeatMode.Restart)
    )
    return Brush.linearGradient(
        colors = listOf(SurfaceHigh, Color(0xFF2C3446), SurfaceHigh),
        start = Offset(x, 0f),
        end = Offset(x + 500f, 300f)
    )
}

@Composable
fun SkeletonList() {
    val brush = rememberShimmerBrush()
    Column(modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 4.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        repeat(5) { SkeletonCard(brush) }
    }
}

@Composable
fun SkeletonCard(brush: Brush) {
    Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = SurfaceColor)) {
        Row(modifier = Modifier.padding(10.dp)) {
            Box(Modifier.width(96.dp).height(150.dp).clip(RoundedCornerShape(12.dp)).background(brush))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Box(Modifier.fillMaxWidth().height(14.dp).clip(RoundedCornerShape(6.dp)).background(brush))
                Spacer(Modifier.height(6.dp))
                Box(Modifier.fillMaxWidth(0.7f).height(14.dp).clip(RoundedCornerShape(6.dp)).background(brush))
                Spacer(Modifier.height(10.dp))
                Box(Modifier.fillMaxWidth(0.55f).height(10.dp).clip(RoundedCornerShape(5.dp)).background(brush))
                Spacer(Modifier.height(12.dp))
                Box(Modifier.fillMaxWidth(0.85f).height(10.dp).clip(RoundedCornerShape(5.dp)).background(brush))
                Spacer(Modifier.height(12.dp))
                Box(Modifier.width(130.dp).height(26.dp).clip(RoundedCornerShape(10.dp)).background(brush))
                Spacer(Modifier.height(10.dp))
                Row {
                    Box(Modifier.width(44.dp).height(18.dp).clip(RoundedCornerShape(8.dp)).background(brush))
                    Spacer(Modifier.width(6.dp))
                    Box(Modifier.width(76.dp).height(18.dp).clip(RoundedCornerShape(8.dp)).background(brush))
                }
            }
        }
    }
}

// =====================================================================
// 🖼️ NETWORK IMAGE COMPOSABLE
// =====================================================================

@Composable
fun NetworkImage(url: String, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    var bitmap by remember(url) { mutableStateOf(ImageLoader.fromMemory(url)) }
    LaunchedEffect(url) {
        if (bitmap == null) bitmap = ImageLoader.load(context.applicationContext, url)
    }
    Box(modifier = modifier.background(SurfaceHigh)) {
        val b = bitmap
        if (b != null) {
            val img = remember(b) { b.asImageBitmap() }
            Image(bitmap = img, contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        } else {
            Box(Modifier.fillMaxSize().background(rememberShimmerBrush()))
        }
    }
}

// =====================================================================
// 🔄 PULL TO REFRESH
// =====================================================================

@Composable
fun PullToRefreshLayout(refreshing: Boolean, onRefresh: () -> Unit, content: @Composable () -> Unit) {
    val thresholdPx = with(LocalDensity.current) { 80.dp.toPx() }
    var pull by remember { mutableStateOf(0f) }
    var flinging by remember { mutableStateOf(false) }
    val currentOnRefresh by rememberUpdatedState(onRefresh)
    val currentRefreshing by rememberUpdatedState(refreshing)

    val connection = remember(thresholdPx) {
        object : NestedScrollConnection {
            override fun onPreScroll(available: Offset, source: NestedScrollSource): Offset {
                if (available.y < 0f && pull > 0f) {
                    val newPull = (pull + available.y).coerceAtLeast(0f)
                    val consumed = newPull - pull
                    pull = newPull
                    return Offset(0f, consumed)
                }
                return Offset.Zero
            }

            override fun onPostScroll(consumed: Offset, available: Offset, source: NestedScrollSource): Offset {
                if (!flinging && available.y > 0f) {
                    pull = (pull + available.y * 0.5f).coerceAtMost(thresholdPx * 1.6f)
                    return Offset(0f, available.y)
                }
                return Offset.Zero
            }

            override suspend fun onPreFling(available: Velocity): Velocity {
                flinging = true
                val trigger = pull >= thresholdPx
                pull = 0f
                if (trigger && !currentRefreshing) currentOnRefresh()
                return Velocity.Zero
            }

            override suspend fun onPostFling(consumed: Velocity, available: Velocity): Velocity {
                flinging = false
                pull = 0f
                return Velocity.Zero
            }
        }
    }

    val shown = if (refreshing) max(pull, thresholdPx * 0.7f) else pull
    val progress = min(shown / thresholdPx, 1f)

    Box(modifier = Modifier.fillMaxSize().nestedScroll(connection)) {
        Box(modifier = Modifier.fillMaxSize().graphicsLayer { translationY = shown }) { content() }
        if (shown > 1f) {
            Box(
                modifier = Modifier.align(Alignment.TopCenter)
                    .graphicsLayer { translationY = shown / 2f - 20f; alpha = progress }
                    .size(40.dp).clip(CircleShape).background(SurfaceHigh),
                contentAlignment = Alignment.Center
            ) {
                if (refreshing) {
                    CircularProgressIndicator(modifier = Modifier.size(22.dp), strokeWidth = 2.dp, color = Accent)
                } else {
                    Text(if (progress >= 1f) "🚀" else "⬇️", fontSize = 16.sp, modifier = Modifier.graphicsLayer { rotationZ = progress * 180f * if (progress >= 1f) 0f else 1f })
                }
            }
        }
    }
}

// =====================================================================
// ❗ ERROR / EMPTY PANELS
// =====================================================================

@Composable
fun ErrorPanel(error: RadarError, onRetry: () -> Unit, onSettings: () -> Unit) {
    val ui = errorUi(error)
    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp).verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier.size(84.dp).clip(CircleShape)
                .background(Brush.radialGradient(listOf(Accent.copy(alpha = 0.35f), Color.Transparent))),
            contentAlignment = Alignment.Center
        ) { Text(ui.emoji, fontSize = 40.sp) }
        Spacer(Modifier.height(16.dp))
        Text(ui.title, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = TextPrimary, textAlign = TextAlign.Center)
        Spacer(Modifier.height(8.dp))
        Text(ui.message, fontSize = 14.sp, color = TextSecondary, textAlign = TextAlign.Center, lineHeight = 20.sp)
        if (error.kind == ErrorKind.QUOTA) {
            Spacer(Modifier.height(14.dp))
            Text(
                "💡 Tip: each search uses more quota than video or channel lookups. Pagination and channel data are cached to save quota.",
                fontSize = 12.sp, color = Amber, textAlign = TextAlign.Center,
                modifier = Modifier.clip(RoundedCornerShape(12.dp)).background(Amber.copy(alpha = 0.1f)).padding(12.dp)
            )
        }
        Spacer(Modifier.height(20.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            if (error.kind != ErrorKind.MISSING_KEY) {
                Button(onClick = onRetry, colors = ButtonDefaults.buttonColors(containerColor = Accent)) { Text("↻ Retry") }
            }
            if (ui.showSettings) {
                OutlinedButton(onClick = onSettings) { Text("⚙️ Settings", color = TextPrimary) }
            }
        }
    }
}

@Composable
fun InlineError(error: RadarError, onRetry: () -> Unit, onDismiss: () -> Unit) {
    val ui = errorUi(error)
    Row(
        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Accent.copy(alpha = 0.12f))
            .border(1.dp, Accent.copy(alpha = 0.4f), RoundedCornerShape(14.dp)).padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(ui.emoji, fontSize = 20.sp)
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(ui.title, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
            Text(ui.message, fontSize = 11.sp, color = TextSecondary, maxLines = 3, overflow = TextOverflow.Ellipsis)
        }
        Text("↻", fontSize = 18.sp, color = Accent, modifier = Modifier.clip(CircleShape).clickable { onRetry() }.padding(8.dp))
        Text("✖️", fontSize = 12.sp, modifier = Modifier.clip(CircleShape).clickable { onDismiss() }.padding(8.dp))
    }
}

@Composable
fun EmptyPanel(emoji: String, title: String, message: String) {
    Column(
        modifier = Modifier.fillMaxSize().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(emoji, fontSize = 48.sp)
        Spacer(Modifier.height(12.dp))
        Text(title, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
        Spacer(Modifier.height(6.dp))
        Text(message, fontSize = 13.sp, color = TextSecondary, textAlign = TextAlign.Center)
    }
}

// =====================================================================
// 🔬 VIDEO INSPECTOR
// =====================================================================

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VideoInspectorSheet(video: Video, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val scope = rememberCoroutineScope()
    val ratio = video.viewToSubRatio

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = SurfaceColor,
        shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
        dragHandle = {
            Box(modifier = Modifier.fillMaxWidth().padding(top = 12.dp, bottom = 6.dp), contentAlignment = Alignment.Center) {
                Box(Modifier.width(44.dp).height(5.dp).clip(RoundedCornerShape(50)).background(TextSecondary.copy(alpha = 0.5f)))
            }
        }
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp).padding(bottom = 32.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("🔬 Video Inspector", fontSize = 13.sp, color = TextSecondary, modifier = Modifier.weight(1f))
                Text("✖️", fontSize = 14.sp, modifier = Modifier.clip(CircleShape).clickable {
                    scope.launch { sheetState.hide() }.invokeOnCompletion { onDismiss() }
                }.padding(8.dp))
            }
            Spacer(Modifier.height(8.dp))
            Row {
                Box(Modifier.width(120.dp).height(200.dp).clip(RoundedCornerShape(16.dp))) {
                    NetworkImage(url = video.thumbnailUrl, modifier = Modifier.fillMaxSize())
                }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(video.title, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = TextPrimary, maxLines = 4, overflow = TextOverflow.Ellipsis)
                    Spacer(Modifier.height(6.dp))
                    Text("👤 ${video.channelTitle}", fontSize = 13.sp, color = TextSecondary, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text("🕒 ${timeAgo(video.publishedAt)} • ⏱ ${formatDuration(video.durationSec)}", fontSize = 12.sp, color = TextSecondary)
                    Spacer(Modifier.height(12.dp))
                    Text(if (ratio != null) formatRatio(ratio) else "—", fontSize = 30.sp, fontWeight = FontWeight.ExtraBold, color = ratioColor(ratio))
                    Text("views per subscriber", fontSize = 11.sp, color = TextSecondary)
                    Spacer(Modifier.height(8.dp))
                    ScoreBar(video.outlierScore)
                }
            }

            Spacer(Modifier.height(18.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatTile("👁", formatCount(video.views), "Views", Modifier.weight(1f))
                StatTile("👥", if (video.hasSubs) formatCount(video.subscribers) else "Hidden", "Subs", Modifier.weight(1f))
                StatTile("🚀", formatCount(video.viewsPerDay), "Views/day", Modifier.weight(1f))
            }
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatTile("❤️", formatCount(video.likes), "Likes", Modifier.weight(1f))
                StatTile("💬", formatCount(video.comments), "Comments", Modifier.weight(1f))
                StatTile("📈", String.format(Locale.US, "%.1f%%", video.engagementRate), "Engagement", Modifier.weight(1f))
            }

            Spacer(Modifier.height(18.dp))
            SectionTitle("🪝 Hook")
            InfoBox(video.hook)
            Spacer(Modifier.height(12.dp))
            SectionTitle("🎵 Audio")
            InfoBox(video.audio)
            Spacer(Modifier.height(12.dp))
            SectionTitle("#️⃣ Hashtags")
            if (video.hashtags.isEmpty()) {
                InfoBox("No hashtags detected")
            } else {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(video.hashtags, key = { it }) { tag ->
                        Pill(text = tag, emoji = null, selected = false, onClick = { copyText(context, tag) })
                    }
                }
            }

            Spacer(Modifier.height(22.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(
                    onClick = { shareText(context, buildShareText(video), video.title) },
                    modifier = Modifier.weight(1f).height(50.dp),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Accent)
                ) { Text("📤 Share", fontWeight = FontWeight.Bold) }
                Button(
                    onClick = { openUrl(context, video.url) },
                    modifier = Modifier.weight(1f).height(50.dp),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = SurfaceHigh)
                ) { Text("▶️ Watch", color = TextPrimary, fontWeight = FontWeight.Bold) }
            }
            Spacer(Modifier.height(10.dp))
            OutlinedButton(
                onClick = { copyText(context, buildShareText(video)) },
                modifier = Modifier.fillMaxWidth().height(46.dp),
                shape = RoundedCornerShape(14.dp)
            ) { Text("📋 Copy report", color = TextPrimary) }
        }
    }
}

@Composable
fun ScoreBar(score: Int) {
    Column {
        Text("⚡ Outlier Score $score/100", fontSize = 12.sp, color = TextPrimary, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(4.dp))
        Box(Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(50)).background(SurfaceHigh)) {
            Box(
                Modifier.fillMaxWidth(score.coerceIn(2, 100) / 100f).height(8.dp).clip(RoundedCornerShape(50))
                    .background(Brush.horizontalGradient(listOf(Electric, Accent)))
            )
        }
    }
}

@Composable
fun SectionTitle(text: String) {
    Text(text, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextPrimary, modifier = Modifier.padding(bottom = 6.dp))
}

@Composable
fun InfoBox(text: String) {
    Text(
        text, fontSize = 13.sp, color = TextPrimary,
        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(SurfaceHigh).padding(12.dp)
    )
}

// =====================================================================
// 📈 TRENDS
// =====================================================================

@Composable
fun TrendsScreen(state: RadarState, vm: RadarViewModel) {
    val context = LocalContext.current
    val report = remember(state.videos) { buildTrends(state.videos) }

    if (report == null) {
        EmptyPanel("📈", "No trend data yet", "Run a search on the Radar tab. Trends, hooks, audio, and your Creator Action Plan are generated from the results.")
        return
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item(key = "head") {
            Column {
                Text("📈 Trends: \"${state.lastQuery}\"", fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, color = TextPrimary, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text("Based on ${report.count} Shorts • ${state.timeWindow.label}", fontSize = 12.sp, color = TextSecondary)
            }
        }
        item(key = "stats") {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatTile("📊", formatRatio(report.avgRatio), "Avg ratio", Modifier.weight(1f))
                StatTile("🏆", formatRatio(report.topRatio), "Top", Modifier.weight(1f))
                StatTile("🌱", "${report.smallCreatorShare}%", "Under 50K", Modifier.weight(1f))
            }
        }
        item(key = "plan") {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color.Transparent),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    Modifier.fillMaxWidth()
                        .background(Brush.linearGradient(listOf(Electric.copy(alpha = 0.35f), Accent.copy(alpha = 0.22f))))
                        .padding(16.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("🎯 Creator Action Plan", fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, color = TextPrimary, modifier = Modifier.weight(1f))
                        Text("📤", fontSize = 18.sp, modifier = Modifier.clip(CircleShape).clickable {
                            val txt = buildString {
                                appendLine("🎯 Creator Action Plan — \"${state.lastQuery}\"")
                                report.plan.forEachIndexed { i, s -> appendLine(); appendLine("${i + 1}. ${s.emoji} ${s.title}"); appendLine(s.detail) }
                                if (report.hashtags.isNotEmpty()) { appendLine(); append("#️⃣ " + report.hashtags.take(5).joinToString(" ") { it.first }) }
                            }
                            shareText(context, txt, "Creator Action Plan")
                        }.padding(6.dp))
                    }
                    Spacer(Modifier.height(10.dp))
                    report.plan.forEachIndexed { i, step ->
                        Row(modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                            Box(Modifier.size(30.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.15f)), contentAlignment = Alignment.Center) {
                                Text("${i + 1}", fontWeight = FontWeight.Bold, color = TextPrimary)
                            }
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text("${step.emoji} ${step.title}", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                                Spacer(Modifier.height(2.dp))
                                Text(step.detail, fontSize = 12.sp, color = TextPrimary.copy(alpha = 0.8f), lineHeight = 17.sp)
                            }
                        }
                    }
                }
            }
        }
        if (report.hashtags.isNotEmpty()) {
            item(key = "tags") { BarSection("#️⃣ Trending Hashtags", report.hashtags, Electric) { copyText(context, it) } }
        }
        if (report.audio.isNotEmpty()) {
            item(key = "audio") { BarSection("🎵 Trending Audio", report.audio, Mint) { copyText(context, it) } }
        }
        item(key = "hooks_title") { SectionTitle("🪝 Hooks from Top Outliers") }
        items(report.hooks, key = { "hook_" + it.id }) { v ->
            Row(
                modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(SurfaceColor)
                    .clickable { copyText(context, v.hook) }.padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("\"${v.hook}\"", fontSize = 13.sp, color = TextPrimary, modifier = Modifier.weight(1f))
                Spacer(Modifier.width(8.dp))
                MiniBadge(v.viewToSubRatio?.let { formatRatio(it) } ?: formatCount(v.views), ratioColor(v.viewToSubRatio))
            }
        }
        if (report.topOutliers.isNotEmpty()) {
            item(key = "top_title") { SectionTitle("🏆 Top 5 Outliers") }
            items(report.topOutliers, key = { "top_" + it.id }) { v ->
                VideoCard(video = v, onClick = { vm.openInspector(v) })
            }
        }
    }
}

@Composable
fun BarSection(title: String, data: List<Pair<String, Int>>, color: Color, onTap: (String) -> Unit) {
    val maxCount = data.maxOfOrNull { it.second } ?: 1
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(SurfaceColor).padding(14.dp)) {
        SectionTitle(title)
        data.forEach { (label, count) ->
            Column(Modifier.fillMaxWidth().clickable { onTap(label) }.padding(vertical = 5.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(label, fontSize = 13.sp, color = TextPrimary, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                    Text("$count", fontSize = 12.sp, color = TextSecondary)
                }
                Spacer(Modifier.height(4.dp))
                Box(Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(50)).background(SurfaceHigh)) {
                    Box(Modifier.fillMaxWidth(count.toFloat() / maxCount.toFloat()).height(6.dp).clip(RoundedCornerShape(50)).background(color))
                }
            }
        }
    }
}

// =====================================================================
// ⚙️ SETTINGS
// =====================================================================

@Composable
fun SettingsScreen(state: RadarState, vm: RadarViewModel) {
    val context = LocalContext.current
    var keyInput by remember(state.apiKey) { mutableStateOf(state.apiKey) }
    var reveal by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("⚙️ Settings", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, color = TextPrimary)

        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(SurfaceColor).padding(16.dp)) {
            SectionTitle("🔑 YouTube Data API v3 Key")
            Text("Google Cloud Console → APIs & Services → enable \"YouTube Data API v3\" → Credentials → Create API key.", fontSize = 12.sp, color = TextSecondary)
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(
                value = keyInput,
                onValueChange = { keyInput = it },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                placeholder = { Text("AIza…", color = TextSecondary) },
                visualTransformation = if (reveal) VisualTransformation.None else PasswordVisualTransformation(),
                trailingIcon = {
                    Text(if (reveal) "🙈" else "👁", fontSize = 18.sp, modifier = Modifier.clip(CircleShape).clickable { reveal = !reveal }.padding(10.dp))
                },
                shape = RoundedCornerShape(14.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Accent,
                    unfocusedBorderColor = Divider,
                    cursorColor = Accent,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                )
            )
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(
                    onClick = {
                        vm.saveApiKey(keyInput)
                        Toast.makeText(context, "API key saved", Toast.LENGTH_SHORT).show()
                    },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = Accent)
                ) { Text("💾 Save") }
                OutlinedButton(onClick = { vm.testKey(keyInput) }, modifier = Modifier.weight(1f), enabled = !state.isTestingKey) {
                    if (state.isTestingKey) CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp, color = Accent)
                    else Text("🧪 Test key", color = TextPrimary)
                }
            }
            state.keyTestMessage?.let {
                Spacer(Modifier.height(10.dp))
                InfoBox(it)
            }
            if (state.apiKey.isNotBlank()) {
                Spacer(Modifier.height(10.dp))
                TextButton(onClick = { vm.setTab(Tab.HOME) }) { Text("📡 Go to Radar →", color = Accent) }
            }
        }

        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(SurfaceColor).padding(16.dp)) {
            SectionTitle("⏳ Quota")
            Text("Free projects get a daily quota. ${quotaResetText()} Channel subscriber data is cached in memory, and each scroll page costs one search plus two cheap lookups.", fontSize = 12.sp, color = TextSecondary, lineHeight = 17.sp)
        }

        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(SurfaceColor).padding(16.dp)) {
            SectionTitle("🧹 Storage")
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(onClick = {
                    ImageLoader.clear(context.applicationContext)
                    Toast.makeText(context, "Image cache cleared", Toast.LENGTH_SHORT).show()
                }, modifier = Modifier.weight(1f)) { Text("🖼️ Clear images", color = TextPrimary) }
                OutlinedButton(onClick = { vm.clearRecent() }, modifier = Modifier.weight(1f)) { Text("🕘 Clear recent", color = TextPrimary) }
            }
        }

        Text("Outlier Radar • YouTube Data API v3", fontSize = 11.sp, color = TextSecondary, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
    }
}